webpackHotUpdate(0,{

/***/ 312:
/***/ function(module, exports, __webpack_require__) {

	exports = module.exports = __webpack_require__(313)();
	// imports


	// module
	exports.push([module.id, "#player {\n  position: fixed;\n  left: 0px;\n  bottom: 0px;\n  width: 100%;\n  height: 70px;\n  background: #DBDBDB;\n}\n#player-time {\n  height: 100%;\n  width: 20%;\n  background: #B7B7B7;\n}\n#player-controls {\n  height: 30px;\n  width: 100%;\n}\n", ""]);

	// exports


/***/ }

})