webpackHotUpdate(0,{

/***/ 312:
/***/ function(module, exports, __webpack_require__) {

	exports = module.exports = __webpack_require__(313)();
	// imports


	// module
	exports.push([module.id, "#player {\n  position: fixed;\n  left: 0px;\n  bottom: 0px;\n  width: 100%;\n  height: 50px;\n  background: #DBDBDB;\n}\n#player:hover {\n  height: 70px;\n}\n#player:hover #player-time {\n  height: 30px;\n}\n#player:hover #current-time {\n  display: block;\n}\n#player-time {\n  min-width: 10px;\n  height: 10px;\n  width: 0%;\n  background: #FC0;\n  transition: width 0.2s ease-in-out;\n}\n#player-controls {\n  height: 50px;\n  width: 100%;\n  background: #ECECEC;\n  padding-left: 10px;\n  padding-top: 5px;\n}\n#player-controls .btn {\n  margin-left: 10px;\n  margin-right: 10px;\n  width: 30px;\n  height: 30px;\n  background-size: 30px 30px;\n  display: inline-block;\n}\n#player-text {\n  vertical-align: middle;\n  margin: 20%;\n  padding-bottom: 21px;\n}\n#current-time {\n  float: right;\n  position: absolute;\n  right: 5px;\n  margin-top: 5px;\n  display: none;\n}\n#play {\n  background: url(" + __webpack_require__(314) + ");\n}\n#play.pause {\n  background: url(" + __webpack_require__(315) + ");\n  background-size: 30px 30px;\n}\n#next {\n  background: url(" + __webpack_require__(316) + ");\n}\n#prev {\n  background: url(" + __webpack_require__(317) + ");\n}\n#volume-level {\n  position: fixed;\n  right: 10px;\n  bottom: 10px;\n  width: 30px;\n  height: 100px;\n  background: #ececec;\n  display: none;\n  padding-top: 5px;\n}\n#volume-level .spliter {\n  background: #AAA;\n  width: 10px;\n  height: 95%;\n  margin: 10px;\n  position: absolute;\n  bottom: 0;\n  margin-bottom: 0;\n  transition: height 0.2s ease-in-out;\n}\n#volume-level .spliter-background {\n  top: 0;\n  background: #D4D4D4;\n}\n#volume {\n  background: url(" + __webpack_require__(318) + ");\n  float: right;\n  padding-right: 10px;\n  background-repeat: no-repeat;\n}\n#volume:hover #volume-level {\n  display: block;\n}\n.current_selected {\n  background: #E4E4E4 !important;\n}\n", ""]);

	// exports


/***/ }

})