webpackHotUpdate(0,{

/***/ 312:
/***/ function(module, exports, __webpack_require__) {

	exports = module.exports = __webpack_require__(313)();
	// imports


	// module
	exports.push([module.id, "#player {\n  position: fixed;\n  left: 0px;\n  bottom: 0px;\n  width: 100%;\n  height: 50px;\n  background: #DBDBDB;\n}\n#player:hover {\n  height: 70px;\n}\n#player:hover #player-time {\n  height: 30px;\n}\n#player-time {\n  min-width: 10px;\n  height: 10px;\n  width: 0%;\n  background: #FC0;\n  transition: width 0.2s ease-in-out;\n}\n#player-controls {\n  height: 50px;\n  width: 100%;\n  background: #ECECEC;\n  padding-left: 10px;\n  padding-top: 5px;\n}\n#player-controls .btn {\n  margin-left: 10px;\n  margin-right: 10px;\n  width: 30px;\n  height: 30px;\n  background-size: 30px 30px;\n  display: inline-block;\n}\n#play {\n  background: url(" + __webpack_require__(315) + ");\n}\n#play.pause {\n  background: url(" + __webpack_require__(318) + ");\n}\n#next {\n  background: url(" + __webpack_require__(317) + ");\n}\n#prev {\n  background: url(" + __webpack_require__(316) + ");\n}\n", ""]);

	// exports


/***/ },

/***/ 318:
/***/ function(module, exports) {

	module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEwAACxMBAJqcGAAAAZ5JREFUeJzt07FuE0EYRtGfCJJ3BwkCUVp4QkgQdEEKRdKA5Gpn5bXuOdKWHn+evZ4BAAAAAAAAAFjvZma+zMzjzDwveh5m5tPMXC/a9/nA+y7e3ay72P+f2wX77g++7+L9nP0u+GHBvt8H37fJm3MPmJeL2NOW3/h2Zp5WDTnhrO/g6pxfzvkJIE4AcQKIE0CcAOIEECeAOAHECSBOAHECiBNAnADiBBAngDgBxAkgTgBxAogTQJwA4gQQJ4A4AcQJIE4AcQKIE0CcAOIEECeAOAHECSBOAHECiBNAnADiBBAngDgBxAkgTgBxAogTQJwA4gQQJ4A4AcQJIE4AcQKIE0CcAOIEECeAOAHECSBOAHECiBNAnADiBBAngDgBxAkgTgBxAogTQJwA4gQQJ4A4AcQJIE4AcQKIE0CcAOIEECeAOAHECSBOAHECiBNAnADiBBAngDgBxB0hgMcdz/6x8fN/ZubXiiEnbN232REC+Lbj2V8XnHH0fRfv3cx8nJd/w/Oi5/vMfHg9e6vrnfa9X7QPAAAAAAAAAOAffwENZLttc+lMMgAAAABJRU5ErkJggg=="

/***/ }

})