webpackHotUpdate(0,{

/***/ 312:
/***/ function(module, exports, __webpack_require__) {

	exports = module.exports = __webpack_require__(313)();
	// imports


	// module
	exports.push([module.id, "#player {\n  position: fixed;\n  left: 0px;\n  bottom: 0px;\n  width: 100%;\n  height: 50px;\n  background: #DBDBDB;\n}\n#player:hover {\n  height: 70px;\n}\n#player:hover #player-time {\n  height: 30px;\n}\n#player-time {\n  min-width: 10px;\n  height: 10px;\n  width: 0%;\n  background: #FC0;\n  transition: width 0.2s ease-in-out;\n}\n#player-controls {\n  height: 50px;\n  width: 100%;\n  background: #ECECEC;\n  padding-top: 5px;\n}\n#player-controls .btn {\n  margin-left: 10px;\n  margin-right: 10px;\n}\n#play {\n  /*width: 30px;\n\theight: 30px;\n\tbackground: #B7B7B7;*/\n  display: inline-block;\n  width: 0;\n  height: 0;\n  border-top: 15px solid transparent;\n  border-left: 26px solid #B7B7B7;\n  border-bottom: 15px solid transparent;\n}\n#next {\n  display: inline-block;\n  width: 0;\n  height: 0;\n  border-top: 15px solid transparent;\n  border-left: 15px solid #B7B7B7;\n  border-bottom: 15px solid transparent;\n}\n#next::before {\n  content: \"\";\n  position: static;\n  display: inline-block;\n  width: 0px;\n  height: 0px;\n  border-top: 15px solid transparent;\n  border-left: 15px solid #B7B7B7;\n  border-bottom: 15px solid transparent;\n  margin-left: -23px;\n  margin-top: -15px;\n}\n", ""]);

	// exports


/***/ }

})