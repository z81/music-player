webpackHotUpdate(0,{

/***/ 312:
/***/ function(module, exports, __webpack_require__) {

	exports = module.exports = __webpack_require__(313)();
	// imports


	// module
	exports.push([module.id, "#player {\n  position: fixed;\n  left: 0px;\n  bottom: 0px;\n  width: 100%;\n  height: 50px;\n  background: #DBDBDB;\n}\n#player:hover {\n  height: 70px;\n}\n#player:hover #player-time:hover {\n  height: 30px;\n}\n#player-time {\n  height: 10px;\n  width: 0%;\n  background: #B7B7B7;\n  transition: width 0.2s ease-in-out;\n}\n#player-controls {\n  height: 50px;\n  width: 100%;\n  background: #ECECEC;\n}\n#play {\n  width: 30px;\n  height: 30px;\n  background: #B7B7B7;\n  display: inline-block;\n}\n", ""]);

	// exports


/***/ }

})